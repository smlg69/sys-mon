// utils/encoding.ts - Упрощенная версия

/**
 * Функция для исправления кодировки из Windows-1251 в UTF-8
 * Использует математическое смещение
 */
export function decodeWindows1251(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Если нет признаков неправильной кодировки, возвращаем как есть
  if (!/РЎ|Рў|Р Р|Р›|Рњ|Рќ/.test(text)) {
    return text;
  }
  
  // Сначала пробуем TextDecoder API (если доступен и поддерживает windows-1251)
  try {
    if (typeof TextDecoder !== 'undefined') {
      const decoder = new TextDecoder('windows-1251');
      const bytes = new Uint8Array(text.length);
      
      for (let i = 0; i < text.length; i++) {
        bytes[i] = text.charCodeAt(i) & 0xFF;
      }
      
      const decoded = decoder.decode(bytes);
      // Проверяем, что декодирование сработало
      if (decoded !== text && !/РЎ|Рў|Р Р|Р›|Рњ|Рќ/.test(decoded)) {
        return decoded;
      }
    }
  } catch (error) {
    // Если TextDecoder не сработал, используем ручное преобразование
    console.warn('TextDecoder не сработал, используем ручное преобразование');
  }
  
  // Ручное преобразование через математическое смещение
  return convertCp1251Manually(text);
}

/**
 * Ручное преобразование CP1251 → UTF-8 через смещение
 */
function convertCp1251Manually(text: string): string {
  let result = '';
  
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    
    // Русские заглавные буквы в CP1251: 0xC0-0xDF → UTF-16: 0x0410-0x042F
    if (charCode >= 0xC0 && charCode <= 0xDF) {
      result += String.fromCharCode(charCode + 0x0350); // 0x0410 - 0xC0 = 0x0350
    }
    // Русские строчные буквы в CP1251: 0xE0-0xFF → UTF-16: 0x0430-0x044F
    else if (charCode >= 0xE0 && charCode <= 0xFF) {
      result += String.fromCharCode(charCode + 0x0350); // 0x0430 - 0xE0 = 0x0350
    }
    // Специальные символы
    else if (charCode === 0xA8) { // Ё
      result += 'Ё';
    } else if (charCode === 0xB8) { // ё
      result += 'ё';
    }
    // Все остальные символы оставляем как есть
    else {
      result += text[i];
    }
  }
  
  return result;
}

/**
 * Альтернативный метод с заменой наиболее частых слов
 */
export function decodeWindows1251Simple(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Если нет признаков неправильной кодировки
  if (!/РЎ|Рў|Р Р|Р›|Рњ|Рќ/.test(text)) {
    return text;
  }
  
  let result = text;
  
  // Список наиболее частых слов для замены
  const commonWords = [
    // Статусы
    { from: 'РЎРѕР·РґР°РЅР°', to: 'Создана' },
    { from: 'Р’ СЂР°Р±РѕС‚Рµ', to: 'В работе' },
    { from: 'Р—Р°РєСЂС‹С‚Р°', to: 'Закрыта' },
    // Приоритеты
    { from: 'РЎСЂРµРґРЅРёР№', to: 'Средний' },
    { from: 'Р’С‹СЃРѕРєРёР№', to: 'Высокий' },
    { from: 'РќРёР·РєРёР№', to: 'Низкий' },
    { from: 'РљСЂРёС‚РёС‡РµСЃРєРёР№', to: 'Критический' },
    // Типы заявок
    { from: 'РћР±СЃР»СѓР¶РёРІР°РЅРёРµ', to: 'Обслуживание' },
    { from: 'Р—Р°РјРµРЅР°', to: 'Замена' },
    { from: 'Р РµРјРѕРЅС‚', to: 'Ремонт' },
    { from: 'РќР°СЃС‚СЂРѕР№РєР°', to: 'Настройка' },
    // Фамилии
    { from: 'РРІР°РЅРѕРІ', to: 'Иванов' },
    { from: 'РЎРјРёСЂРЅРѕРІ', to: 'Смирнов' },
    { from: 'Р’Р°СЃРёР»СЊРµРІ', to: 'Васильев' },
    { from: 'РџРѕРїРѕРІ', to: 'Попов' },
    { from: 'РЎРёРґРѕСЂРѕРІ', to: 'Сидоров' },
    { from: 'РњР°С…РјСѓРґРѕРІ', to: 'Махмудов' },
    // Инициалы
    { from: 'Рђ\\.Р›\\.', to: 'А.Л.' },
    { from: 'Рњ\\.РЎ\\.', to: 'М.С.' },
    { from: 'Рџ\\.Рљ\\.', to: 'П.К.' },
    { from: 'Р”\\.Р’\\.', to: 'Д.В.' },
    { from: 'Р\\.Р\\.', to: 'И.И.' },
    { from: 'Р\\.Рљ\\.', to: 'И.К.' },
  ];
  
  // Применяем замены
  commonWords.forEach(({ from, to }) => {
    result = result.replace(new RegExp(from, 'g'), to);
  });
  
  // Если после замены все еще есть проблемы, используем полное преобразование
  if (/РЎ|Рў|Р Р|Р›|Рњ|Рќ/.test(result)) {
    result = convertCp1251Manually(result);
  }
  
  return result;
}

/**
 * Функция для исправления всей заявки
 */
export function decodeOrder(order: any): any {
  if (!order || typeof order !== 'object') return order;
  
  const decoded: any = {};
  
  Object.keys(order).forEach(key => {
    const value = order[key];
    if (typeof value === 'string') {
      decoded[key] = decodeWindows1251(value);
    } else {
      decoded[key] = value;
    }
  });
  
  return decoded;
}

/**
 * Функция для исправления массива заявок
 */
export function decodeOrdersArray(orders: any[]): any[] {
  if (!Array.isArray(orders)) return orders;
  
  return orders.map(order => decodeOrder(order));
}

/**
 * Тестовая функция для проверки декодирования
 */
export function testDecoding(): void {
  const testCases = [
    { input: 'РћР±СЃР»СѓР¶РёРІР°РЅРёРµ', expected: 'Обслуживание' },
    { input: 'РЎСЂРµРґРЅРёР№', expected: 'Средний' },
    { input: 'РРІР°РЅРѕРІ Рџ.Рљ.', expected: 'Иванов П.К.' },
    { input: 'РџСЂРѕС„РёР»Р°РєС‚РёС‡РµСЃРєРѕРµ РѕР±СЃР»СѓР¶РёРІР°РЅРёРµ', expected: 'Профилактическое обслуживание' },
  ];
  
  console.log('🧪 Тестирование декодирования:');
  testCases.forEach(({ input, expected }) => {
    const result = decodeWindows1251(input);
    const passed = result === expected;
    console.log(`   ${passed ? '✅' : '❌'} "${input}" → "${result}" (ожидалось: "${expected}")`);
  });
}